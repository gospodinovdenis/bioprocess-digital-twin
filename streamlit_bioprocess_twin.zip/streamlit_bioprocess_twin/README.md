# Integrated Bioprocess Digital Twin

A deployment-ready Streamlit portfolio application combining:

- a mechanistic fed-batch mammalian-cell model implemented with SciPy;
- interactive upstream process controls and visualization;
- a downstream chromatography dashboard designed to display CADET-Core /
  CADET-Process simulation outputs.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. In Streamlit Community Cloud, choose **Create app**.
4. Select the repository and branch.
5. Set the main file path to:

```text
app.py
```

6. Deploy.

No secrets are required for the app.

## Project structure

```text
streamlit_bioprocess_twin/
├── app.py
├── requirements.txt
├── README.md
├── .streamlit/
│   └── config.toml
└── data/
    └── processed/
        ├── fitted_parameters.csv
        ├── optimal_process.csv
        ├── demo_cadet_capture_outlet.csv
        └── demo_cadet_capture_metrics.csv
```

## Upstream Reactor

The upstream module solves a mechanistic fed-batch ODE system and lets the user
change growth, death, substrate-consumption, product-formation, and feed
parameters interactively.

## Downstream CADET Purification

The dashboard first looks for these files:

```text
data/processed/cadet_capture_outlet.csv
data/processed/cadet_capture_metrics.csv
```

If they are present, the app displays them as CADET-generated results.

If they are absent, the app uses the included files:

```text
data/processed/demo_cadet_capture_outlet.csv
data/processed/demo_cadet_capture_metrics.csv
```

The included demo files are intentionally labeled as **illustrative preview
data** and are not represented as an executed CADET-Core simulation.

### Replacing the preview with your real CADET results

Run the CADET cells in `DIGdigitaltwin_CADET_dashboard.ipynb`. Copy the generated
files into `data/processed/` using these exact names:

```text
cadet_capture_outlet.csv
cadet_capture_metrics.csv
```

Commit and push them to GitHub. On the next Streamlit deployment/reboot, the app
will automatically use the real CADET result files instead of the preview data.

## CADET-Core on the Streamlit server

This deployment package intentionally does **not** install or execute
CADET-Core on each Streamlit rerun. The dashboard consumes precomputed CADET
results. This makes the public app lightweight and reliable while preserving
the CADET workflow in the accompanying modeling notebook.

## Scientific note

The downstream chromatography parameters in the modeling notebook are
illustrative unless replaced with experimentally fitted resin/process data.
